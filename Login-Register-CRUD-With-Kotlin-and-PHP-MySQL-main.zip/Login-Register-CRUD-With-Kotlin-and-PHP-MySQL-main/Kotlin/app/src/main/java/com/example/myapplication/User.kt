package com.example.myapplication

class User (val id:Int,val username:String,val email:String) {

}