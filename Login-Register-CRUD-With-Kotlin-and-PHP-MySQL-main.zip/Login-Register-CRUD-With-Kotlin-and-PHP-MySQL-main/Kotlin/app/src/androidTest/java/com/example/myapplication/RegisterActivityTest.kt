package com.example.myapplication

import androidx.test.platform.app.InstrumentationRegistry
import junit.framework.TestCase
import org.junit.*

class RegisterActivityTest : TestCase() {

    @Before
    public override fun setUp(){ super.setUp() }

    @Test
    fun Testing(){



    }

    @After
    public override fun tearDown(){}

}